package com.zing.basket.util;


public class Product{
	
	private String product_name;
	private String product_code;
	private String product_barcode;
	private String product_department;
	private String product_division;
	private String product_family;
	private String product_groupfamily;
	private String product_subfamily;
	private String product_grammage;
	private String product_mrp;
	private String product_bbprice;
	private String product_qty;
	private String product_value;
	
	public void setProductName (String product_name)
	{
	    this.product_name = product_name;
	}
	
	public String getProductName()
	{
	    return product_name;
	}

	public void setProductGrammage (String product_grammage)
	{
	    this.product_grammage = product_grammage;
	}
	
	public String getProductGrammage()
	{
	    return product_grammage;
	}
	
	public void setProductBarcode (String product_barcode)
	{
	    this.product_barcode = product_barcode;
	}
	
	public String getProductBarcode()
	{
	    return product_barcode;
	}
	
	public void setProductDivision (String product_division)
	{
	    this.product_division = product_division;
	}
	
	public String getProductDivision()
	{
	    return product_division;
	}
	
	public void setProductDepartment (String product_department)
	{
	    this.product_department = product_department;
	}
	
	public String getProductDepartment()
	{
	    return product_department;
	}
	
	public void setProductFamily (String product_family)
	{
	    this.product_family = product_family;
	}
	
	public String getProductFamily()
	{
	    return product_family;
	}
	
	public void setProductGroupFamily (String product_groupfamily)
	{
	    this.product_groupfamily = product_groupfamily;
	}
	
	public String getProductGroupFamily()
	{
	    return product_groupfamily;
	}
	
	public void setProductSubFamily (String product_subfamily)
	{
	    this.product_subfamily = product_subfamily;
	}
	
	public String getProductSubFamily()
	{
	    return product_subfamily;
	}
	
	public void setProductMRP (String product_mrp)
	{
	    this.product_mrp = product_mrp;
	}
	
	public String getProductMRP()
	{
	    return product_mrp;
	}
	
	public void setProductBBPrice (String product_bbprice)
	{
	    this.product_bbprice = product_bbprice;
	}
	
	public String getProductBBPrice()
	{
	    return product_bbprice;
	}
	
	public void setProductQty (String product_qty)
	{
	    this.product_qty = product_qty;
	}
	
	public String getProductQty()
	{
	    return product_qty;
	}
	
	public void setProductValue (String product_value)
	{
	    this.product_value = product_value;
	}
	
	public String getProductValue()
	{
	    return product_value;
	}
	
	public void setProductCode(String product_code)
	{
	    this.product_code = product_code;
	}
	
	public String getProductCode()
	{
	    return product_code;
	}
}
